from .cjx_plugin import classFactory
