from qgis.PyQt.QtWidgets import QAction, QMessageBox
from .cjx_ui import CJXDialog
import traceback

def classFactory(iface):
    return CJXPlugin(iface)

class CJXPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dlg = None

    def initGui(self):
        self.action = QAction("CJx_Ratio", self.iface.mainWindow())
        self.action.setWhatsThis("Summarize houses/surveys/dorms by polygon (EPSG:4326)")
        self.action.triggered.connect(self.run_dialog)
        self.iface.addPluginToMenu("&CJx_Ratio", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&CJx_Ratio", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None
        self.dlg = None

    def run_dialog(self):
        try:
            self.dlg = CJXDialog(self.iface)
            self.dlg.show()
        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "CJx_Ratio", f"Failed to open dialog:\\n{e}\\n{traceback.format_exc()}")
