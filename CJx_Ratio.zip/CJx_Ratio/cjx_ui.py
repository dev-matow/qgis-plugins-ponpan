from qgis.PyQt import QtWidgets
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtCore import QVariant
from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
from .cjx_worker import compute_summary

def _order_fields_for_numeric_first(lyr, prefer_keys=None):
    def is_numeric_field(f):
        try:
            num_types = set()
            for n in ("Int", "Double", "LongLong", "UInt", "ULongLong"):
                if hasattr(QVariant, n):
                    num_types.add(getattr(QVariant, n))
            if f.type() in num_types:
                return True
        except Exception:
            pass
        try:
            tn = (f.typeName() or "").lower()
            for key in ["int","integer","double","real","float","numeric","decimal"]:
                if key in tn:
                    return True
        except Exception:
            pass
        return False
    prefer_keys = prefer_keys or []
    numeric, textlike = [], []
    for f in lyr.fields():
        (numeric if is_numeric_field(f) else textlike).append(f.name())
    def sort_key(n):
        p = 0 if any(k in n.lower() for k in prefer_keys) else 1
        return (p, n.lower())
    numeric.sort(key=sort_key); textlike.sort(key=sort_key)
    return numeric + textlike

class CJXDialog(QtWidgets.QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("CJx_Ratio — Summary by polygon (auto EPSG:4326)")
        self.setMinimumWidth(600)

        self.layer_poly = QtWidgets.QComboBox()
        self.layer_house = QtWidgets.QComboBox()
        self.layer_survey = QtWidgets.QComboBox()
        self.bill_field = QtWidgets.QComboBox()
        self.layer_dorm = QtWidgets.QComboBox()
        self.rooms_field = QtWidgets.QComboBox()
        self.use_dorm = QtWidgets.QCheckBox("ใช้ชั้น หอพัก (ออปชัน)")
        self.use_dorm.setChecked(False)

        self.predicate = QtWidgets.QComboBox()
        self.predicate.addItems(["within (แนะนำ)", "intersects"])
        self.output_name = QtWidgets.QLineEdit("CJx_Ratio_summary")

        form = QtWidgets.QFormLayout()
        form.addRow("โพลิกอน (สังเขป):", self.layer_poly)
        form.addRow("จุดบ้าน:", self.layer_house)
        form.addRow("จุดแบบสอบถาม:", self.layer_survey)
        form.addRow("ฟิลด์จำนวนบิล:", self.bill_field)
        form.addRow(self.use_dorm)
        form.addRow("ชั้น หอพัก:", self.layer_dorm)
        form.addRow("ฟิลด์จำนวนห้อง:", self.rooms_field)
        form.addRow("เงื่อนไขเชิงพื้นที่:", self.predicate)
        form.addRow("ชื่อเลเยอร์ผลลัพธ์:", self.output_name)

        btns = QtWidgets.QDialogButtonBox()
        btn_run = btns.addButton("Run", QtWidgets.QDialogButtonBox.AcceptRole)
        btn_cancel = btns.addButton("Close", QtWidgets.QDialogButtonBox.RejectRole)
        btn_run.clicked.connect(self.on_run)
        btn_cancel.clicked.connect(self.reject)

        v = QtWidgets.QVBoxLayout(self); v.addLayout(form); v.addWidget(btns)

        self.layer_dorm.setEnabled(False); self.rooms_field.setEnabled(False)
        self.use_dorm.stateChanged.connect(self.toggle_dorm)

        self.layer_survey.currentIndexChanged.connect(self.populate_bill_fields)
        self.layer_dorm.currentIndexChanged.connect(self.populate_rooms_fields)

        self.populate_layer_lists(); self.populate_bill_fields(); self.populate_rooms_fields()

    def toggle_dorm(self, state):
        enabled = self.use_dorm.isChecked()
        self.layer_dorm.setEnabled(enabled); self.rooms_field.setEnabled(enabled)

    def layers(self):
        proj = QgsProject.instance()
        return [l for l in proj.mapLayers().values() if isinstance(l, QgsVectorLayer)]

    def populate_layer_lists(self):
        def add_layers(combo, geom_types):
            combo.clear()
            for lyr in self.layers():
                try: gt = lyr.geometryType()
                except Exception: continue
                if gt in geom_types: combo.addItem(lyr.name(), lyr.id())
            if combo.count() == 0: combo.addItem("(no layer)", "")
        add_layers(self.layer_poly, [QgsWkbTypes.PolygonGeometry])
        add_layers(self.layer_house, [QgsWkbTypes.PointGeometry])
        add_layers(self.layer_survey, [QgsWkbTypes.PointGeometry])
        add_layers(self.layer_dorm, [QgsWkbTypes.PointGeometry])

    def get_layer_by_combo(self, combo):
        lyr_id = combo.currentData()
        if not lyr_id: return None
        return QgsProject.instance().mapLayer(lyr_id)

    def populate_bill_fields(self):
        self.bill_field.clear()
        lyr = self.get_layer_by_combo(self.layer_survey)
        if not lyr: self.bill_field.addItem("(none)", ""); return
        for name in _order_fields_for_numeric_first(lyr, ["bill"]):
            self.bill_field.addItem(name, name)
        if self.bill_field.count() == 0: self.bill_field.addItem("(no fields)", "")

    def populate_rooms_fields(self):
        self.rooms_field.clear()
        lyr = self.get_layer_by_combo(self.layer_dorm)
        if not lyr: self.rooms_field.addItem("(none)", ""); return
        for name in _order_fields_for_numeric_first(lyr, ["room","rooms","unit","ห้อง"]):
            self.rooms_field.addItem(name, name)
        if self.rooms_field.count() == 0: self.rooms_field.addItem("(no fields)", "")

    def on_run(self):
        try:
            poly = self.get_layer_by_combo(self.layer_poly)
            house = self.get_layer_by_combo(self.layer_house)
            survey = self.get_layer_by_combo(self.layer_survey)
            bill_field = self.bill_field.currentData()
            if not poly or not house or not survey or not bill_field:
                raise ValueError("กรุณาเลือกโพลิกอน, จุดบ้าน, จุดแบบสอบถาม และฟิลด์จำนวนบิลให้ครบถ้วน")
            dorm = None; rooms_field = None
            if self.use_dorm.isChecked():
                dorm = self.get_layer_by_combo(self.layer_dorm)
                rooms_field = self.rooms_field.currentData()
                if not dorm or not rooms_field:
                    raise ValueError("เปิดใช้ หอพัก แล้วต้องเลือกชั้นหอพัก และฟิลด์จำนวนห้อง")

            predicate = "within" if self.predicate.currentIndex() == 0 else "intersects"
            out_name = self.output_name.text().strip() or "CJx_Ratio_summary"

            res_layer = compute_summary(
                poly_layer=poly, house_layer=house, survey_layer=survey, bill_field=bill_field,
                dorm_layer=dorm, rooms_field=rooms_field, predicate=predicate,
                output_name=out_name, iface=self.iface
            )
            if res_layer:
                QMessageBox.information(self, "CJx_Ratio", f"สำเร็จ: สร้างเลเยอร์ '{res_layer.name()}' (EPSG:4326)")
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "CJx_Ratio - Error", str(e))
