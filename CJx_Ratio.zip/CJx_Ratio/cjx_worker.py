__all__ = ["compute_summary"]

import re
from qgis.core import (
    QgsFeature, QgsField, QgsProject, QgsVectorLayer, QgsSpatialIndex, QgsFeatureRequest,
    QgsWkbTypes, QgsCoordinateReferenceSystem, QgsCoordinateTransform
)
from qgis.PyQt.QtCore import QVariant

_NUM_RE = re.compile(r"[-+]?(\d+([.,]\d+)?|[.,]\d+)")

def _to_float(val):
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    try:
        s = str(val).strip().replace(" ", "")
        if s == "":
            return None
        if "," in s and "." in s:
            s = s.replace(",", "")
        elif "," in s:
            s = s.replace(",", ".")
        return float(s)
    except Exception:
        try:
            m = _NUM_RE.search(str(val))
            if m:
                return float(m.group(0).replace(",", "."))
        except Exception:
            pass
    return None

def _geom_name_from_type(geom_type):
    if geom_type == QgsWkbTypes.PointGeometry:
        return "Point"
    if geom_type == QgsWkbTypes.LineGeometry:
        return "LineString"
    return "Polygon"

def _mk_memory_poly_like(src_layer, out_name):
    crs = QgsCoordinateReferenceSystem("EPSG:4326").toWkt()
    dst = QgsVectorLayer(f"Polygon?crs={crs}", out_name, "memory")
    prov = dst.dataProvider()
    prov.addAttributes(src_layer.fields())
    prov.addAttributes([
        QgsField("house_count", QVariant.Int),
        QgsField("survey_count", QVariant.Int),
        QgsField("bill_total", QVariant.Double)
    ])
    dst.updateFields()
    return dst

def _add_dorm_fields(layer):
    prov = layer.dataProvider()
    prov.addAttributes([
        QgsField("dorm_count", QVariant.Int),
        QgsField("rooms_total", QVariant.Double)
    ])
    layer.updateFields()

def _reproject_copy(src_layer, target_authid="EPSG:4326"):
    if src_layer is None:
        return None
    target = QgsCoordinateReferenceSystem(target_authid)
    src_crs = src_layer.crs()
    try:
        if src_crs == target:
            return src_layer
    except Exception:
        pass

    geom_name = _geom_name_from_type(src_layer.geometryType())
    dst = QgsVectorLayer(f"{geom_name}?crs={target.toWkt()}", src_layer.name()+"_4326", "memory")
    prov = dst.dataProvider()
    prov.addAttributes(src_layer.fields())
    dst.updateFields()

    tr = QgsCoordinateTransform(src_crs, target, QgsProject.instance().transformContext())

    feats = []
    for f in src_layer.getFeatures():
        nf = QgsFeature(dst.fields())
        nf.setAttributes(f.attributes())
        try:
            g = f.geometry()
            g.transform(tr)  # in-place; returns int status in older QGIS
            nf.setGeometry(g)
        except Exception:
            continue
        feats.append(nf)

    prov.addFeatures(feats)
    dst.updateExtents()
    return dst

def compute_summary(poly_layer, house_layer, survey_layer, bill_field,
                    dorm_layer=None, rooms_field=None, predicate="within",
                    output_name="CJx_Ratio_summary", iface=None):

    # Ensure all inputs are 4326
    poly = _reproject_copy(poly_layer, "EPSG:4326")
    house = _reproject_copy(house_layer, "EPSG:4326")
    survey = _reproject_copy(survey_layer, "EPSG:4326")
    dorm = _reproject_copy(dorm_layer, "EPSG:4326") if dorm_layer else None

    # Spatial indexes
    house_index = QgsSpatialIndex(house.getFeatures())
    survey_index = QgsSpatialIndex(survey.getFeatures())
    dorm_index = QgsSpatialIndex(dorm.getFeatures()) if dorm else None

    # Output (Polygon, EPSG:4326)
    out = _mk_memory_poly_like(poly, output_name)
    if dorm:
        _add_dorm_fields(out)
    out_prov = out.dataProvider()
    out_fields = out.fields()

    idx_house = out_fields.indexOf("house_count")
    idx_scount = out_fields.indexOf("survey_count")
    idx_btotal = out_fields.indexOf("bill_total")
    idx_dcount = out_fields.indexOf("dorm_count") if dorm else -1
    idx_rtotal = out_fields.indexOf("rooms_total") if dorm else -1

    src_fields = poly.fields()
    src_names = [f.name() for f in src_fields]

    new_feats = []
    for f in poly.getFeatures():
        poly_geom = f.geometry()
        bbox = poly_geom.boundingBox()

        # Houses
        house_cnt = 0
        for hid in house_index.intersects(bbox):
            for hf in house.getFeatures(QgsFeatureRequest(hid)):
                if (poly_geom.contains(hf.geometry()) if predicate == "within" else poly_geom.intersects(hf.geometry())):
                    house_cnt += 1

        # Surveys
        survey_cnt = 0
        bill_sum = 0.0
        for sid in survey_index.intersects(bbox):
            for sf in survey.getFeatures(QgsFeatureRequest(sid)):
                if (poly_geom.contains(sf.geometry()) if predicate == "within" else poly_geom.intersects(sf.geometry())):
                    survey_cnt += 1
                    v = _to_float(sf[bill_field])
                    if v is not None:
                        bill_sum += v

        # Dorms
        dorm_cnt = 0
        rooms_sum = 0.0
        if dorm and dorm_index:
            for did in dorm_index.intersects(bbox):
                for df in dorm.getFeatures(QgsFeatureRequest(did)):
                    if (poly_geom.contains(df.geometry()) if predicate == "within" else poly_geom.intersects(df.geometry())):
                        dorm_cnt += 1
                        v = _to_float(df[rooms_field])
                        if v is not None:
                            rooms_sum += v

        newf = QgsFeature(out_fields)
        attrs = [f[name] if name in src_names else None for name in src_names]
        while len(attrs) < out_fields.count(): attrs.append(None)

        attrs[idx_house] = int(house_cnt)
        attrs[idx_scount] = int(survey_cnt)
        attrs[idx_btotal] = float(bill_sum)
        if dorm:
            attrs[idx_dcount] = int(dorm_cnt)
            attrs[idx_rtotal] = float(rooms_sum)

        newf.setAttributes(attrs)
        newf.setGeometry(poly_geom)
        new_feats.append(newf)

    out_prov.addFeatures(new_feats)
    out.updateExtents()
    QgsProject.instance().addMapLayer(out)
    return out
