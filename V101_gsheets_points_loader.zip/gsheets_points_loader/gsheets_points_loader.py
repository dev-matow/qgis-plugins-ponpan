from qgis.PyQt.QtCore import QSettings, QTimer
from qgis.PyQt.QtWidgets import QAction, QInputDialog, QMessageBox
from qgis.core import (
    QgsVectorLayer,
    QgsProject,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY
)
from PyQt5.QtCore import QVariant

import csv
import io
import urllib.request


class GSheetsPointsLoader:

    AUTO_REFRESH_SECONDS = 10800  # 3 ชั่วโมง

    def __init__(self, iface):
        self.iface = iface
        self.menu_name = "&GSheets Points Loader"

        self.action_setup = None
        self.action_refresh = None

        self.layer = None

        self.settings = QSettings()
        self.key_url = "gsheets_points_loader/csv_url"
        self.key_layer_name = "gsheets_points_loader/layer_name"

        self.csv_url = self.settings.value(self.key_url, "", type=str)
        self.layer_name = self.settings.value(self.key_layer_name, "GSheets_Points", type=str)

        # Timer
        self.timer = QTimer()
        self.timer.timeout.connect(self.refresh)

    def initGui(self):
        self.action_setup = QAction("GSheets Setup", self.iface.mainWindow())
        self.action_setup.triggered.connect(self.setup)

        self.action_refresh = QAction("GSheets Refresh", self.iface.mainWindow())
        self.action_refresh.triggered.connect(self.refresh)

        self.iface.addPluginToMenu(self.menu_name, self.action_setup)
        self.iface.addPluginToMenu(self.menu_name, self.action_refresh)

        self.iface.addToolBarIcon(self.action_setup)
        self.iface.addToolBarIcon(self.action_refresh)

        # ถ้ามี URL อยู่แล้ว โหลดครั้งแรก
        if self.csv_url:
            self.refresh()
            self.timer.start(self.AUTO_REFRESH_SECONDS * 1000)
            self.iface.messageBar().pushMessage(
                "GSheets",
                "Auto Refresh ทุก 3 ชั่วโมง เริ่มทำงานแล้ว",
                level=0,
                duration=5
            )

    def unload(self):
        if self.action_setup:
            self.iface.removePluginMenu(self.menu_name, self.action_setup)
            self.iface.removeToolBarIcon(self.action_setup)
        if self.action_refresh:
            self.iface.removePluginMenu(self.menu_name, self.action_refresh)
            self.iface.removeToolBarIcon(self.action_refresh)

        self.timer.stop()

    # -------------------------
    # Setup
    # -------------------------
    def setup(self):
        url, ok = QInputDialog.getText(
            self.iface.mainWindow(),
            "GSheets Setup",
            "ใส่ URL CSV:",
            text=self.csv_url
        )
        if not ok:
            return

        url = (url or "").strip()
        if not url:
            QMessageBox.warning(self.iface.mainWindow(), "GSheets Setup", "URL ว่าง")
            return

        lname, ok = QInputDialog.getText(
            self.iface.mainWindow(),
            "GSheets Setup",
            "ชื่อเลเยอร์:",
            text=self.layer_name
        )
        if not ok:
            return

        self.csv_url = url
        self.layer_name = lname.strip() if lname else "GSheets_Points"

        self.settings.setValue(self.key_url, self.csv_url)
        self.settings.setValue(self.key_layer_name, self.layer_name)

        # เริ่ม Auto Timer
        self.refresh()
        self.timer.start(self.AUTO_REFRESH_SECONDS * 1000)

        self.iface.messageBar().pushMessage(
            "GSheets",
            "ตั้งค่าแล้ว และเริ่ม Auto Refresh ทุก 3 ชั่วโมง",
            level=0,
            duration=5
        )

    # -------------------------
    # Refresh Logic
    # -------------------------
    def refresh(self):
        if not self.csv_url:
            return

        try:
            text = self._download_text(self.csv_url)
            rows, headers = self._parse_csv(text)

            lat_key, lon_key, loc_key = self._detect_coord_fields(headers)

            if not ((lat_key and lon_key) or loc_key):
                return

            self._build_or_update_layer(headers, rows, lat_key, lon_key, loc_key)

        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "GSheets Error", str(e))

    def _download_text(self, url: str) -> str:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = resp.read()
        return data.decode("utf-8-sig", errors="replace")

    def _parse_csv(self, text: str):
        f = io.StringIO(text)
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        rows = list(reader)
        return rows, headers

    def _detect_coord_fields(self, headers):
        lower_map = {h.lower(): h for h in headers}

        lat_key = lower_map.get("latitude") or lower_map.get("lat")
        lon_key = lower_map.get("longitude") or lower_map.get("lon") or lower_map.get("lng")
        loc_key = lower_map.get("location")

        return lat_key, lon_key, loc_key

    def _build_or_update_layer(self, headers, rows, lat_key, lon_key, loc_key):

        if self.layer is None or QgsProject.instance().mapLayer(self.layer.id()) is None:
            self.layer = QgsVectorLayer("Point?crs=EPSG:4326", self.layer_name, "memory")
            pr = self.layer.dataProvider()

            fields = QgsFields()
            for h in headers:
                fields.append(QgsField(h, QVariant.String))
            pr.addAttributes(fields)
            self.layer.updateFields()

            QgsProject.instance().addMapLayer(self.layer)

        self.layer.startEditing()
        self.layer.dataProvider().truncate()

        feats = []

        for r in rows:
            lat, lon = None, None

            if lat_key and lon_key:
                lat = self._to_float(r.get(lat_key))
                lon = self._to_float(r.get(lon_key))
            elif loc_key:
                lat, lon = self._parse_location(r.get(loc_key))

            if lat is None or lon is None:
                continue

            feat = QgsFeature(self.layer.fields())
            feat.setAttributes([r.get(h, "") for h in headers])
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
            feats.append(feat)

        self.layer.addFeatures(feats)
        self.layer.commitChanges()
        self.layer.triggerRepaint()

    def _to_float(self, x):
        try:
            return float(str(x).strip())
        except:
            return None

    def _parse_location(self, s):
        try:
            parts = str(s).split(",")
            return float(parts[0]), float(parts[1])
        except:
            return None, None