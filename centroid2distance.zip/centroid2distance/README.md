﻿# centroid2distance

QGIS Processing Plugin สำหรับคำนวณระยะทางตามโครงข่ายถนน (Drive Network) จากจุดเป้าหมายที่ผู้ใช้ระบุ (`lat, lon`) ไปยัง centroid ของแต่ละกลุ่มในชั้นข้อมูล polygon แล้วบันทึกผลเป็นฟิลด์ใหม่ `road_distance_km` ในเลเยอร์ผลลัพธ์

## คุณสมบัติ
- เลือกชั้นข้อมูล Polygon และฟิลด์สำหรับจัดกลุ่มได้จาก dropdown
- รวม geometry ตามกลุ่ม (dissolve) และหา centroid ต่อกลุ่ม
- ดึงโครงข่ายถนนจาก OpenStreetMap ผ่าน OSMnx (`network_type='drive'`)
- คำนวณ shortest path distance ตามถนนด้วย NetworkX
- เขียนผลกลับเป็นเลเยอร์ใหม่ (ไม่ทับเลเยอร์ต้นฉบับ)

## ข้อกำหนด
- QGIS 3.1+
- Python package: `osmnx`, `networkx`

ติดตั้ง package ใน OSGeo4W Shell (Run as Administrator):

```powershell
python3 -m pip install --upgrade pip
python3 -m pip install osmnx networkx
```

ถ้า `pip` ยังไม่พร้อม:

```powershell
python3 -m ensurepip
python3 -m pip install osmnx networkx
```

## การติดตั้งปลั๊กอิน
1. คัดลอกโฟลเดอร์ `centroid2distance` ไปที่โฟลเดอร์ปลั๊กอินของ QGIS
2. เปิด QGIS แล้วไปที่ `Plugins > Manage and Install Plugins...`
3. เปิดใช้งานปลั๊กอิน `centroid2distance`

## วิธีใช้งาน
1. เปิด Processing Toolbox
2. เรียกอัลกอริทึม `Centroid to Drive Distance (OSMnx)`
3. ตั้งค่าอินพุต:
- `Polygon layer (with grouping attribute)`
- `Group field (dropdown)`
- `Target point (lat, lon)` ตัวอย่าง: `13.714967, 100.162206`
- `Snap warning threshold (meters)` (ค่าเริ่มต้น 300)
- `Max search radius around target for OSM graph (meters)` (ค่าเริ่มต้น 30000)
4. เลือก Output layer แล้วรัน
5. ตรวจผลในฟิลด์ `road_distance_km`

## พารามิเตอร์สำคัญ
- `TARGET_COORDS`: รองรับรูปแบบ `lat, lon` หรือคั่นด้วยช่องว่าง
- `MAX_RADIUS_M`: จำกัดรัศมีการโหลดกราฟ OSM รอบจุดเป้าหมาย
- `SNAP_WARN_M`: แจ้งเตือนเมื่อ centroid ถูก snap ไปโหนดถนนไกลเกิน threshold

## หมายเหตุ
- ระยะทางเป็นระยะทางตามถนน (ไม่ใช่ระยะเส้นตรง)
- หากหาเส้นทางไม่เจอ ค่าใน `road_distance_km` จะเป็นค่าว่าง (`NULL`)
- ความเร็วขึ้นกับจำนวนกลุ่ม, พื้นที่ค้นหา และการเชื่อมต่ออินเทอร์เน็ต

## โครงสร้างไฟล์หลัก
- `centroid2distance_algorithm.py` อัลกอริทึมหลัก
- `centroid2distance_provider.py` ลงทะเบียน Processing provider
- `centroid2distance_plugin.py` lifecycle ของปลั๊กอิน
- `metadata.txt` ข้อมูลปลั๊กอินสำหรับ QGIS
