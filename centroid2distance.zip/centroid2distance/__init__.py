# -*- coding: utf-8 -*-
"""Entry point for QGIS to load this plugin."""

def classFactory(iface):
    from .centroid2distance_plugin import Centroid2DistancePlugin
    return Centroid2DistancePlugin(iface)
