# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QVariant, QCoreApplication
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterString,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingException,
    QgsFeature,
    QgsFeatureSink,
    QgsFields,
    QgsField,
    QgsGeometry,
    QgsWkbTypes,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsPointXY,
)
import math

class Centroid2DistanceAlgorithm(QgsProcessingAlgorithm):
    """Compute per-group centroids, snap to OSM drive graph, and measure shortest-path distance to a user target point."""

    INPUT = 'INPUT'
    GROUP_FIELD = 'GROUP_FIELD'
    TARGET_COORDS = 'TARGET_COORDS'  # 'lat, lon'
    SNAP_WARN_M = 'SNAP_WARN_M'
    MAX_RADIUS_M = 'MAX_RADIUS_M'
    OUTPUT = 'OUTPUT'

    def tr(self, text):
        return QCoreApplication.translate('Centroid2DistanceAlgorithm', text)

    def createInstance(self):
        return Centroid2DistanceAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, self.tr('Polygon layer (with grouping attribute)'),
            [QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterField(
            self.GROUP_FIELD, self.tr('Group field (dropdown)'),
            parentLayerParameterName=self.INPUT, type=QgsProcessingParameterField.Any))
        self.addParameter(QgsProcessingParameterString(
            self.TARGET_COORDS, self.tr('Target point (lat, lon)'),
            defaultValue='13.714967152342853, 100.1622056012167'))
        self.addParameter(QgsProcessingParameterNumber(
            self.SNAP_WARN_M, self.tr('Snap warning threshold (meters)'),
            type=QgsProcessingParameterNumber.Double, defaultValue=300.0, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_RADIUS_M, self.tr('Max search radius around target for OSM graph (meters)'),
            type=QgsProcessingParameterNumber.Double, defaultValue=30000.0, optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, self.tr('Output layer (new)')))

    def name(self): return 'centroid2distance'
    def displayName(self): return self.tr('Centroid to Drive Distance (OSMnx)')
    def group(self): return self.tr('Analysis')
    def groupId(self): return 'analysis'
    def shortHelpString(self):
        return self.tr('Dissolve by selected group → centroid per group → OSMnx drive-network shortest path from target (lat,lon) to each centroid. Writes road_distance_km to a new layer.')

    # helpers
    @staticmethod
    def _parse_lat_lon(text):
        cleaned = text.replace('\n',' ').replace('\t',' ').replace('[','').replace(']','').replace('(','').replace(')','')
        parts = [p for p in cleaned.replace(',', ' ').split(' ') if p]
        if len(parts) < 2: raise QgsProcessingException('TARGET_COORDS must be like: 13.7149, 100.1622')
        try: lat = float(parts[0]); lon = float(parts[1])
        except Exception: raise QgsProcessingException('TARGET_COORDS must be numeric lat, lon')
        if not (-90 <= lat <= 90 and -180 <= lon <= 180): raise QgsProcessingException('TARGET_COORDS out of range')
        return lat, lon

    @staticmethod
    def _utm_epsg_for_latlon(lat, lon):
        zone = int(math.floor((lon + 180.0) / 6.0) + 1)
        return (32600 if lat >= 0 else 32700) + zone

    @staticmethod
    def _haversine_m(lat1, lon1, lat2, lon2):
        R = 6371000.0
        p1, p2 = math.radians(lat1), math.radians(lat2)
        dphi = p2 - p1
        dl = math.radians(lon2 - lon1)
        a = math.sin(dphi/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
        return 2*R*math.atan2(math.sqrt(a), math.sqrt(1-a))

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None: raise QgsProcessingException('Failed to read INPUT layer')
        group_field = self.parameterAsString(parameters, self.GROUP_FIELD, context)
        target_text = self.parameterAsString(parameters, self.TARGET_COORDS, context)
        snap_warn_m = self.parameterAsDouble(parameters, self.SNAP_WARN_M, context)
        max_radius_m = self.parameterAsDouble(parameters, self.MAX_RADIUS_M, context)

        lat_t, lon_t = self._parse_lat_lon(target_text)  # user lat,lon

        in_crs = source.sourceCrs()
        wgs84 = QgsCoordinateReferenceSystem('EPSG:4326')
        to_wgs = QgsCoordinateTransform(in_crs, wgs84, QgsProject.instance())

        center_wgs = to_wgs.transform(source.sourceExtent().center())
        utm = QgsCoordinateReferenceSystem(f"EPSG:{self._utm_epsg_for_latlon(center_wgs.y(), center_wgs.x())}")
        to_utm = QgsCoordinateTransform(in_crs, utm, QgsProject.instance())
        utm_to_wgs = QgsCoordinateTransform(utm, wgs84, QgsProject.instance())

        # dissolve & centroid per group
        groups = {}
        for feat in source.getFeatures():
            key = feat[group_field]; geom = feat.geometry()
            if not geom or geom.isEmpty(): continue
            groups.setdefault(key, []).append(geom)
        if not groups: raise QgsProcessingException('No geometries in INPUT')

        centroids_wgs = {}
        for gkey, geoms in groups.items():
            u = QgsGeometry.unaryUnion(geoms)
            g_utm = QgsGeometry(u); g_utm.transform(to_utm)
            cen = g_utm.centroid()
            cen_wgs = QgsGeometry(cen); cen_wgs.transform(utm_to_wgs)
            pt = cen_wgs.asPoint()
            centroids_wgs[gkey] = (pt.y(), pt.x())  # (lat, lon)

        # radius to cover all centroids
        dists = [self._haversine_m(lat_t, lon_t, lat, lon) for (lat, lon) in centroids_wgs.values()]
        dmax = max(dists) if dists else 0.0
        margin = max(2000.0, dmax * 0.2)
        radius = max(1500.0, min((dmax + margin), max_radius_m if max_radius_m else (dmax + margin)))
        feedback.pushInfo(self.tr(f'OSM graph radius: {int(radius)} m (dmax={int(dmax)}, margin={int(margin)})'))

        try:
            import osmnx as ox, networkx as nx
        except Exception as e:
            raise QgsProcessingException('Requires Python packages: osmnx, networkx. ' + str(e))

        # Load and PROJECT the graph so nearest searches work without scikit-learn
        try:
            G = ox.graph_from_point((lat_t, lon_t), dist=float(radius), network_type='drive', simplify=True)
            Gp = ox.projection.project_graph(G)  # projected to meters
        except Exception as e:
            raise QgsProcessingException(f'Failed to load/project OSM graph: {e}')

        # graph CRS
        graph_crs = None
        try:
            crs_py = Gp.graph.get('crs', None)
            epsg = None
            if crs_py is not None:
                try: epsg = crs_py.to_epsg()
                except Exception: epsg = None
                if epsg:
                    graph_crs = QgsCoordinateReferenceSystem(f"EPSG:{epsg}")
                else:
                    try:
                        wkt = crs_py.to_wkt()
                        graph_crs = QgsCoordinateReferenceSystem(); graph_crs.createFromWkt(wkt)
                    except Exception: graph_crs = None
        except Exception: graph_crs = None
        if graph_crs is None: graph_crs = utm

        to_graph = QgsCoordinateTransform(wgs84, graph_crs, QgsProject.instance())

        # Transform target & centroids
        t_xy = to_graph.transform(QgsPointXY(lon_t, lat_t)); tx, ty = t_xy.x(), t_xy.y()
        group_keys = list(centroids_wgs.keys())
        lats = [centroids_wgs[k][0] for k in group_keys]
        lons = [centroids_wgs[k][1] for k in group_keys]
        xy_proj = [to_graph.transform(QgsPointXY(lons[i], lats[i])) for i in range(len(group_keys))]
        xs = [p.x() for p in xy_proj]; ys = [p.y() for p in xy_proj]

        try:
            nearest_nodes = ox.distance.nearest_nodes
        except AttributeError:
            nearest_nodes = ox.nearest_nodes

        try:
            target_node = nearest_nodes(Gp, tx, ty)
        except Exception as e:
            raise QgsProcessingException(f'Failed to snap target point (projected): {e}')

        try:
            snap_nodes = nearest_nodes(Gp, xs, ys)
        except Exception as e:
            raise QgsProcessingException(f'Failed to snap centroids (projected): {e}')

        node_x = [Gp.nodes[n]['x'] for n in snap_nodes]
        node_y = [Gp.nodes[n]['y'] for n in snap_nodes]
        snap_dist_m = [((xs[i]-node_x[i])**2 + (ys[i]-node_y[i])**2)**0.5 for i in range(len(group_keys))]

        distances_km = {}; warn_count = 0
        for i, gkey in enumerate(group_keys):
            n = snap_nodes[i]
            try:
                length_m = nx.shortest_path_length(Gp, n, target_node, weight='length')
                distances_km[gkey] = round(float(length_m) / 1000.0, 2)
            except Exception:
                distances_km[gkey] = None
            if snap_warn_m and snap_dist_m[i] > snap_warn_m: warn_count += 1

        if warn_count: feedback.pushInfo(self.tr(f'⚠ {warn_count} centroid(s) snapped farther than {int(snap_warn_m)} m.'))

        orig_fields = source.fields(); out_fields = QgsFields()
        for f in orig_fields: out_fields.append(f)
        desired = 'road_distance_km'; name = desired
        existing = {f.name() for f in orig_fields}; i = 1
        while name in existing: name = f'{desired}_{i}'; i += 1
        out_fields.append(QgsField(name, QVariant.Double))

        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, out_fields,
                                             source.wkbType() if source.wkbType()!=QgsWkbTypes.Unknown else QgsWkbTypes.MultiPolygon,
                                             source.sourceCrs())
        if sink is None: raise QgsProcessingException('Failed to create OUTPUT sink')

        new_feat = QgsFeature(out_fields)
        for feat in source.getFeatures():
            attrs = feat.attributes(); gkey = feat[group_field]
            dist_val = distances_km.get(gkey, None)
            new_feat.setGeometry(feat.geometry())
            new_feat.setAttributes(list(attrs) + [None if dist_val is None else float(dist_val)])
            sink.addFeature(new_feat, QgsFeatureSink.FastInsert)

        return {self.OUTPUT: dest_id}
