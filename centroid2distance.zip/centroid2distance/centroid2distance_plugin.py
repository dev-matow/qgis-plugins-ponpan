# -*- coding: utf-8 -*-
from qgis.core import QgsApplication
from .centroid2distance_provider import Centroid2DistanceProvider

class Centroid2DistancePlugin:
    """Registers Processing provider for centroid2distance."""

    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initGui(self):
        self.provider = Centroid2DistanceProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
