# -*- coding: utf-8 -*-
from qgis.core import QgsProcessingProvider
from .centroid2distance_algorithm import Centroid2DistanceAlgorithm

class Centroid2DistanceProvider(QgsProcessingProvider):
    def id(self):
        return 'centroid2distance'

    def name(self):
        return self.tr('centroid2distance')

    def longName(self):
        return self.name()

    def loadAlgorithms(self):
        self.addAlgorithm(Centroid2DistanceAlgorithm())
