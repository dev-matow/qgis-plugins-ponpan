﻿# CSVtoGeojson (QGIS Plugin)

![CSVtoGeojson Logo](icon.png)

ปลั๊กอิน QGIS สำหรับแปลงข้อมูล CSV เป็นจุดบนแผนที่และส่งออกเป็น GeoJSON โดยรองรับทั้งการโหลดจาก URL และไฟล์ `.csv` ในเครื่อง

## คุณสมบัติ

- โหลดข้อมูล CSV ได้ 2 แบบ
  - วางลิงก์ URL (เช่น Google Sheets แบบ `output=csv`)
  - เลือกไฟล์ `.csv` จากเครื่อง
- เลือกคอลัมน์พิกัดแบบคู่ `(lat, lon)`
- เลือกคอลัมน์สำหรับกรอง `Branch` และ `data Survey` ผ่าน dropdown
- กรองข้อมูลตามค่า `Branch` และ `data Survey`
- Preview เป็นเลเยอร์ชั่วคราวใน QGIS
- Export เป็นไฟล์ GeoJSON (EPSG:4326)
- ข้ามแถวพิกัดไม่ถูกต้องอัตโนมัติ

## ความต้องการระบบ

- QGIS `>= 3.1.0`

## การติดตั้ง

1. ปิด QGIS
2. คัดลอกโฟลเดอร์ปลั๊กอินไปที่:
   - `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\cjx_csv2geojson`
3. เปิด QGIS
4. ไปที่ `Plugins > Manage and Install Plugins...`
5. เปิดใช้งานปลั๊กอิน

## วิธีใช้งาน

1. เปิดปลั๊กอิน `CJX CSV -> GeoJSON`
2. เลือกแหล่งข้อมูลอย่างใดอย่างหนึ่ง
   - วาง `CSV URL`
   - หรือกดปุ่ม `Choose .csv File`
3. กด `โหลดหัวตาราง`
4. เลือก `Pair column` (คอลัมน์พิกัด)
5. ในส่วน Filter เลือก
   - `Branch column`
   - `Time column`
   จากนั้นเลือกค่า `Branch` และ `data Survey`
6. กด `พรีวิว` หรือ `บันทึก GeoJSON`

## รูปแบบพิกัดที่รองรับ

- `(13.7563, 100.5018)`
- `13.7563,100.5018`
- `13.7563 100.5018`

เงื่อนไข:

- Latitude ต้องอยู่ในช่วง `-90..90`
- Longitude ต้องอยู่ในช่วง `-180..180`

## ไฟล์หลักในโปรเจกต์

- `cjx_csv2geojson.py` - entry plugin
- `cjx_dialog.py` - UI และ workflow
- `helpers.py` - logic โหลด CSV, parse พิกัด, สร้างเลเยอร์, export
- `metadata.txt` - metadata ของ plugin
- `icon.png` - โลโก้ปลั๊กอิน

## ผู้พัฒนา

- Ponpan R.
- Email: `ponpan.tow@gmail.com`
