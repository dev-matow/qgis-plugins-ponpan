# -*- coding: utf-8 -*-
def classFactory(iface):
    from .cjx_csv2geojson import CjxCsv2GeojsonPlugin
    return CjxCsv2GeojsonPlugin(iface)
