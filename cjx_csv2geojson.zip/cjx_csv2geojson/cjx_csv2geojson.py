# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from .cjx_dialog import CjxDialog

class CjxCsv2GeojsonPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dlg = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(QIcon(icon_path), "CJX CSV → GeoJSON", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&CJX CSV → GeoJSON", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&CJX CSV → GeoJSON", self.action)
            self.iface.removeToolBarIcon(self.action)

    def tr(self, message):
        return QCoreApplication.translate('CjxCsv2GeojsonPlugin', message)

    def run(self):
        if not self.dlg:
            self.dlg = CjxDialog(self.iface)
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
