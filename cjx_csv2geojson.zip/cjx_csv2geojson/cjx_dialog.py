
# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QComboBox,
    QHBoxLayout, QLabel, QFileDialog, QMessageBox, QGroupBox, QSpacerItem, QSizePolicy
)
from .helpers import (
    fetch_csv, fetch_csv_file, unique_values, filter_rows,
    rows_to_memory_layer_pair, add_layer_to_project, export_geojson
)

DEFAULT_BRANCH_COL = "สาขา CJx ที่เก็บข้อมูล"
DEFAULT_TIME_COL = "data Survey"
DEFAULT_PAIR_CANDIDATE = "ตำแหน่ง Lat, Long ของคำตอบหลังจากใช้บริการจะเดินทางไปไหนต่อ"
DEFAULT_PAIR_URL = "https://docs.google.com/spreadsheets/d/e/2PACX-1vSK9mcr2oeITiZfMiopHI97PwKGCgIykujXJL-bSox3eH3Vn2BahXHClfxwP-JmbeRrjmPBODBHqPtA/pub?gid=493002311&single=true&output=csv"


class CjxDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("CJX CSV → GeoJSON")

        self.rows = []
        self.headers = []

        main = QVBoxLayout(self)

        # 1) URL
        box_url = QGroupBox("1) ลิงก์ CSV (Google Sheets → CSV)")
        url_layout = QFormLayout()
        self.txtUrl = QLineEdit(DEFAULT_PAIR_URL)
        self.btnPickCsv = QPushButton("Choose .csv File")
        self.btnLoadHeader = QPushButton("โหลดหัวตาราง")
        self.btnPickCsv.clicked.connect(self.on_pick_csv)
        self.btnLoadHeader.clicked.connect(self.on_load_header)
        url_layout.addRow("CSV URL/Path:", self.txtUrl)
        url_layout.addRow("", self.btnPickCsv)
        url_layout.addRow("", self.btnLoadHeader)
        box_url.setLayout(url_layout)

        # 2) Pair column
        box_pair = QGroupBox("2) เลือกคอลัมน์พิกัด (รูปแบบ: (lat, lon))")
        pair_layout = QFormLayout()
        self.cboPair = QComboBox()
        self.lblPairHelp = QLabel("แนะนำ: \"%s\"" % DEFAULT_PAIR_CANDIDATE)
        self.lblPairHelp.setStyleSheet("color: gray;")
        pair_layout.addRow("Pair column:", self.cboPair)
        pair_layout.addRow(self.lblPairHelp)
        box_pair.setLayout(pair_layout)

        # 3) Filters
        box_filter = QGroupBox("3) เลือกสาขาและวันที่")
        flt_layout = QFormLayout()
        self.cboBranchCol = QComboBox()
        self.cboTimeCol = QComboBox()
        self.cboBranch = QComboBox()
        self.cboTime = QComboBox()
        self.cboBranch.currentIndexChanged.connect(self.on_branch_changed)
        self.cboBranchCol.currentIndexChanged.connect(self.on_filter_columns_changed)
        self.cboTimeCol.currentIndexChanged.connect(self.on_filter_columns_changed)
        flt_layout.addRow("Branch column:", self.cboBranchCol)
        flt_layout.addRow("Time column:", self.cboTimeCol)
        flt_layout.addRow("Branch:", self.cboBranch)
        flt_layout.addRow("data Survey:", self.cboTime)
        box_filter.setLayout(flt_layout)

        # 4) Actions
        box_actions = QGroupBox("4) การทำงาน")
        act_layout = QHBoxLayout()
        self.btnPreview = QPushButton("พรีวิว")
        self.btnExport = QPushButton("บันทึก GeoJSON")
        self.btnPreview.clicked.connect(self.on_preview)
        self.btnExport.clicked.connect(self.on_export)
        act_layout.addWidget(self.btnPreview)
        act_layout.addWidget(self.btnExport)
        box_actions.setLayout(act_layout)

        # status
        self.lblStatus = QLabel("")
        self.lblStatus.setWordWrap(True)

        main.addWidget(box_url)
        main.addWidget(box_pair)
        main.addWidget(box_filter)
        main.addWidget(box_actions)
        main.addItem(QSpacerItem(20, 10, QSizePolicy.Minimum, QSizePolicy.Expanding))
        main.addWidget(self.lblStatus)
        self.setMinimumWidth(640)

    def on_pick_csv(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select CSV File", "", "CSV (*.csv)")
        if path:
            self.txtUrl.setText(path)

    def on_load_header(self):
        source = self.txtUrl.text().strip()
        if not source:
            QMessageBox.warning(self, "แจ้งเตือน", "กรุณากรอกลิงก์ CSV")
            return
        try:
            if source.lower().startswith(("http://", "https://")):
                self.rows, self.headers = fetch_csv(source)
            else:
                self.rows, self.headers = fetch_csv_file(source)
        except Exception as e:
            QMessageBox.critical(self, "โหลดไม่สำเร็จ", f"ไม่สามารถโหลด CSV:\n{e}")
            return
        if not self.headers:
            QMessageBox.warning(self, "ข้อผิดพลาด", "ไม่พบหัวตารางใน CSV")
            return

        self.cboPair.clear()
        self.cboPair.addItems(self.headers)
        if DEFAULT_PAIR_CANDIDATE in self.headers:
            self.cboPair.setCurrentIndex(self.headers.index(DEFAULT_PAIR_CANDIDATE))

        self.cboBranchCol.blockSignals(True)
        self.cboTimeCol.blockSignals(True)
        self.cboBranchCol.clear()
        self.cboTimeCol.clear()
        self.cboBranchCol.addItems(self.headers)
        self.cboTimeCol.addItems(self.headers)
        if DEFAULT_BRANCH_COL in self.headers:
            self.cboBranchCol.setCurrentIndex(self.headers.index(DEFAULT_BRANCH_COL))
        if DEFAULT_TIME_COL in self.headers:
            self.cboTimeCol.setCurrentIndex(self.headers.index(DEFAULT_TIME_COL))
        self.cboBranchCol.blockSignals(False)
        self.cboTimeCol.blockSignals(False)

        self.refresh_filter_values()
        self.lblStatus.setText(f"โหลดหัวตารางสำเร็จ: {len(self.headers)} คอลัมน์, ข้อมูล {len(self.rows)} แถว")

    def on_filter_columns_changed(self, idx):
        if not self.rows:
            return
        self.refresh_filter_values()

    def refresh_filter_values(self):
        branch_col = self.cboBranchCol.currentText().strip() or DEFAULT_BRANCH_COL
        branches = unique_values(self.rows, branch_col)
        self.cboBranch.blockSignals(True)
        self.cboBranch.clear()
        self.cboBranch.addItem("")
        self.cboBranch.addItems(branches)
        self.cboBranch.blockSignals(False)
        self.on_branch_changed(self.cboBranch.currentIndex())

    def on_branch_changed(self, idx):
        if not self.rows: return
        branch_col = self.cboBranchCol.currentText().strip() or DEFAULT_BRANCH_COL
        time_col = self.cboTimeCol.currentText().strip() or DEFAULT_TIME_COL
        branch_val = self.cboBranch.currentText().strip()
        rows_b = self.rows if not branch_val else [r for r in self.rows if (r.get(branch_col) or '').strip() == branch_val]
        times = unique_values(rows_b, time_col)
        self.cboTime.clear(); self.cboTime.addItem(""); self.cboTime.addItems(times)

    def _build_layer(self, title=None):
        if not self.rows:
            QMessageBox.warning(self, "ยังไม่ได้โหลด", "กรุณาโหลดหัวตาราง CSV ก่อน")
            return None, 0
        pair_col = self.cboPair.currentText().strip()
        if not pair_col:
            QMessageBox.warning(self, "เลือกคอลัมน์", "กรุณาเลือกคอลัมน์พิกัดคู่")
            return None, 0
        branch_col = self.cboBranchCol.currentText().strip() or DEFAULT_BRANCH_COL
        time_col = self.cboTimeCol.currentText().strip() or DEFAULT_TIME_COL
        branch_val = self.cboBranch.currentText().strip()
        time_val = self.cboTime.currentText().strip()
        rows_f = filter_rows(self.rows, branch_col, branch_val, time_col, time_val)
        if not rows_f:
            QMessageBox.information(self, "ไม่มีข้อมูล", "ไม่มีแถวข้อมูลที่ตรงตามเงื่อนไข")
            return None, 0
        layer_title = title or f"CJX Points [{branch_val or 'ALL'} | {time_val or 'ALL'}]"
        vl, skipped = rows_to_memory_layer_pair(rows_f, layer_title, pair_col, 4326)
        return vl, skipped

    def on_preview(self):
        layer, skipped = self._build_layer()
        if not layer: return
        add_layer_to_project(layer)
        msg = "พรีวิวสำเร็จ"
        if skipped: msg += f" (ข้าม {skipped} แถวที่พิกัดไม่ถูกต้อง)"
        self.lblStatus.setText(msg)

    def on_export(self):
        layer, skipped = self._build_layer()
        if not layer: return
        b = self.cboBranch.currentText().strip() or "ALL"
        t = self.cboTime.currentText().strip() or "ALL"
        suggested = f"cjx_{b}_{t}.geojson".replace(" ", "_").replace("/", "-")
        path, _ = QFileDialog.getSaveFileName(self, "บันทึก GeoJSON", suggested, "GeoJSON (*.geojson)")
        if not path: return
        err = export_geojson(layer, path)
        if err != 0:
            QMessageBox.critical(self, "บันทึกไม่สำเร็จ", f"เกิดข้อผิดพลาด (code {err})")
            return
        msg = f"บันทึกสำเร็จ: {path}"
        if skipped: msg += f" (ข้าม {skipped} แถว)"
        self.lblStatus.setText(msg)
        QMessageBox.information(self, "สำเร็จ", f"บันทึกเป็น GeoJSON แล้ว:\n{path}")
