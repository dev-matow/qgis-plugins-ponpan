
# -*- coding: utf-8 -*-
import csv
import io
import re
from urllib.request import urlopen, Request
from qgis.core import (
    QgsProject, QgsFields, QgsField, QgsFeature, QgsGeometry, QgsPointXY,
    QgsVectorLayer, QgsCoordinateReferenceSystem, QgsVectorFileWriter
)
from qgis.PyQt.QtCore import QVariant

# Load CSV from URL (returns rows, headers)
def fetch_csv(url: str):
    req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urlopen(req) as resp:
        raw = resp.read()
    text = raw.decode('utf-8', errors='replace')
    f = io.StringIO(text)
    reader = csv.DictReader(f)
    rows = [row for row in reader]
    return rows, reader.fieldnames or []

def fetch_csv_file(path: str):
    with open(path, 'r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        rows = [row for row in reader]
    return rows, reader.fieldnames or []

# Coordinate pair pattern: "(lat, lon)" or "lat, lon"
_pair_rx = re.compile(r'\(?\s*([+-]?\d+(?:\.\d+)?)\s*[, ]\s*([+-]?\d+(?:\.\d+)?)\s*\)?')

def parse_pair(value: str):
    # Return (lat, lon) floats or (None, None)
    if value is None:
        return (None, None)
    m = _pair_rx.search(str(value))
    if not m:
        return (None, None)
    lat = float(m.group(1))
    lon = float(m.group(2))
    return (lat, lon)

def safe_lat_lon(lat, lon):
    if lat is None or lon is None:
        return False
    if not (-90.0 <= lat <= 90.0):
        return False
    if not (-180.0 <= lon <= 180.0):
        return False
    return True

def unique_values(rows, col_name):
    s = []
    seen = set()
    for r in rows:
        v = (r.get(col_name) or '').strip()
        if v and v not in seen:
            seen.add(v)
            s.append(v)
    return s

def filter_rows(rows, branch_col, branch_val, time_col, time_val):
    out = []
    for r in rows:
        if branch_val and (r.get(branch_col) or '').strip() != branch_val:
            continue
        if time_val and (r.get(time_col) or '').strip() != time_val:
            continue
        out.append(r)
    return out

def rows_to_memory_layer_pair(rows, layer_name, pair_col, crs_epsg=4326):
    """Create a memory point layer using a single pair column."""
    vl = QgsVectorLayer("Point?crs=EPSG:{}".format(crs_epsg), layer_name, "memory")
    pr = vl.dataProvider()

    # fields from headers + lat_num/lon_num
    headers = set()
    for r in rows:
        headers.update(r.keys())
    fields = QgsFields()
    for h in headers:
        fields.append(QgsField(str(h), QVariant.String))
    fields.append(QgsField("lat_num", QVariant.Double))
    fields.append(QgsField("lon_num", QVariant.Double))
    pr.addAttributes(fields)
    vl.updateFields()

    feats = []
    skipped = 0
    for r in rows:
        lat, lon = parse_pair(r.get(pair_col))
        if not safe_lat_lon(lat, lon):
            skipped += 1
            continue
        f = QgsFeature()
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
        attrs = []
        for h in headers:
            attrs.append(r.get(h))
        attrs.extend([lat, lon])
        f.setAttributes(attrs)
        feats.append(f)

    pr.addFeatures(feats)
    vl.updateExtents()
    return vl, skipped

def add_layer_to_project(layer):
    QgsProject.instance().addMapLayer(layer)

def export_geojson(layer, filepath):
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GeoJSON"
    options.fileEncoding = "UTF-8"
    layer.setCrs(QgsCoordinateReferenceSystem("EPSG:4326"))
    err, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
        layer, filepath, QgsProject.instance().transformContext(), options
    )
    return err  # 0=OK
