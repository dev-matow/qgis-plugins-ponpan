﻿# Expor Data KML/GPKG (QGIS Plugin)

ปลั๊กอินสำหรับ **QGIS** เพื่อส่งออกหลายชั้นข้อมูล (multiple vector layers) ไปยังไฟล์เดียวในรูปแบบ **GPKG** หรือ **KML** โดยรีโปรเจกต์เป็น `EPSG:4326` อัตโนมัติ

## คุณสมบัติหลัก

- ส่งออกหลายเลเยอร์ลงไฟล์เดียว (`GPKG` หรือ `KML`)
- รองรับการเพิ่มเลเยอร์จาก
  - เลเยอร์ที่เลือกใน Layers Panel
  - ทุก Vector Layer ในโปรเจกต์
- จัดลำดับเลเยอร์ก่อนส่งออกได้ (Up/Down)
- รีโปรเจกต์พิกัดเป็น `EPSG:4326` อัตโนมัติ
- รองรับชื่อเลเยอร์ภาษาไทย/Unicode สำหรับ `GPKG` และ `LIBKML`
- หากส่งออกด้วยชื่อ Unicode ไม่สำเร็จ จะลองอีกครั้งด้วยชื่อ ASCII-safe อัตโนมัติ
- โหมดเขียนไฟล์แบบ
  - เลเยอร์แรก: `CreateOrOverwriteFile`
  - เลเยอร์ถัดไป: `CreateOrOverwriteLayer`

## ความต้องการระบบ

- QGIS `>= 3.1.0` และ `<= 3.99`
- ปลั๊กอินประเภท Python
- สำหรับ KML:
  - ถ้ามีไดรเวอร์ `LIBKML` จะใช้งาน `LIBKML` ก่อน
  - หากไม่มี จะ fallback ไป `KML` (บาง build อาจรองรับเพียง 1 เลเยอร์ต่อไฟล์)

## ติดตั้งปลั๊กอิน (แบบโฟลเดอร์)

1. คัดลอกโฟลเดอร์ปลั๊กอินนี้ไปยังโฟลเดอร์ plugins ของ QGIS
2. เปิด QGIS ไปที่ `Plugins > Manage and Install Plugins...`
3. เปิดใช้งานปลั๊กอิน **Expor Data KML/GPKG**

ตัวอย่างตำแหน่งโฟลเดอร์ plugins บน Windows:

`%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`

## วิธีใช้งาน

1. เปิดปลั๊กอินจากเมนู/ไอคอน **Expor Data KML/GPKG**
2. เพิ่มเลเยอร์ที่ต้องการส่งออก
   - `Add Selected (Layers Panel)` หรือ
   - `Add All Vector Layers`
3. เลือกรูปแบบไฟล์ (`GPKG` หรือ `KML`)
4. เลือกพาธไฟล์ปลายทาง (`Browse...`)
5. ถ้าไฟล์มีอยู่แล้วและต้องการทับ ให้ติ๊ก `Overwrite if file exists`
6. กด `Export`
7. ตรวจสอบสถานะจาก Log และ Progress Bar

## เงื่อนไขและข้อควรรู้

- ทุกเลเยอร์ต้องมี CRS ที่ถูกต้องก่อนส่งออก
- ปลั๊กอินจะหยุดและแจ้งเตือนถ้าไม่มี CRS ในบางเลเยอร์
- ถ้าใช้ไดรเวอร์ `KML` ปกติ (ไม่ใช่ `LIBKML`) และส่งออกหลายเลเยอร์ อาจล้มเหลวในบางระบบ
  - แนะนำใช้ `GPKG` หรือเปิดใช้ GDAL ที่มี `LIBKML`

## ข้อมูลปลั๊กอิน

- Name: `Expor Data KML/GPKG`
- Version: `1.0.6`
- Author: `Ponpan R.`
- Email: `ponpan.tow@gmail.com`

## โครงสร้างไฟล์หลัก

- `__init__.py` - entry point ของปลั๊กอิน
- `expor_data_kml_gpkg.py` - โค้ดหลัก UI และ logic การส่งออก
- `metadata.txt` - metadata ของปลั๊กอินสำหรับ QGIS

## License

ยังไม่ได้ระบุ license ใน repository นี้ หากต้องการเผยแพร่ แนะนำเพิ่มไฟล์ `LICENSE` ให้ชัดเจน
