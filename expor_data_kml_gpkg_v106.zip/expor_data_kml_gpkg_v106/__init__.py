# -*- coding: utf-8 -*-
from .expor_data_kml_gpkg import ExporDataKmlGpkg

def classFactory(iface):
    return ExporDataKmlGpkg(iface)