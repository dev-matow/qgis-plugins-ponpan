
# -*- coding: utf-8 -*-
"""
Expor Data KML/GPKG — QGIS Plugin
v1.0.6:
- Preserve Thai/Unicode layer names for GPKG and LIBKML drivers.
- If export fails with Unicode name, retry once with ASCII-safe fallback.
- Keep CreateOrOverwriteFile (first layer) / CreateOrOverwriteLayer (next layers).
"""
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import (
    QgsProject,
    QgsWkbTypes,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsVectorLayer,
)
try:
    from qgis.core import QgsVectorLayerExporter
except Exception:
    QgsVectorLayerExporter = None
from qgis.core import QgsVectorFileWriter
from qgis.gui import QgsMessageBar
import os, re

try:
    from osgeo import ogr
except Exception:
    ogr = None

PLUGIN_MENU_TEXT = "Expor Data KML/GPKG"

class ExporDataKmlGpkg(object):
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dlg = None

    def initGui(self):
        icon = self.iface.mainWindow().style().standardIcon(QtWidgets.QStyle.SP_DialogSaveButton)
        self.action = QtWidgets.QAction(icon, PLUGIN_MENU_TEXT, self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(PLUGIN_MENU_TEXT, self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu(PLUGIN_MENU_TEXT, self.action)
            self.action = None

    def run(self):
        if self.dlg is None:
            self.dlg = ExportDialog(self.iface)
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()


class ExportDialog(QtWidgets.QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("Expor Data KML/GPKG — Export Many Layers")
        self.setWindowModality(QtCore.Qt.NonModal)
        self.resize(740, 560)

        # List
        self.lwLayers = QtWidgets.QListWidget()
        self.lwLayers.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)

        # Buttons
        self.btnAddSelected = QtWidgets.QPushButton("Add Selected (Layers Panel)")
        self.btnAddAll = QtWidgets.QPushButton("Add All Vector Layers")
        self.btnRemove = QtWidgets.QPushButton("Remove")
        self.btnUp = QtWidgets.QPushButton("Up")
        self.btnDown = QtWidgets.QPushButton("Down")

        # Output controls
        self.cboFormat = QtWidgets.QComboBox()
        self.cboFormat.addItems(["GPKG", "KML"])

        self.leOutput = QtWidgets.QLineEdit()
        self.btnBrowse = QtWidgets.QPushButton("Browse…")
        self.chkOverwrite = QtWidgets.QCheckBox("Overwrite if file exists")
        self.chkOverwrite.setChecked(False)

        # Progress + Log
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)

        self.txtLog = QtWidgets.QTextEdit()
        self.txtLog.setReadOnly(True)
        self.txtLog.setPlaceholderText("Log…")

        self.buttonBox = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        self.btnExport = QtWidgets.QPushButton("Export")
        self.btnExport.setDefault(True)
        self.buttonBox.addButton(self.btnExport, QtWidgets.QDialogButtonBox.AcceptRole)

        # Layouts
        leftBtns = QtWidgets.QVBoxLayout()
        leftBtns.addWidget(self.btnAddSelected)
        leftBtns.addWidget(self.btnAddAll)
        leftBtns.addWidget(self.btnRemove)
        leftBtns.addWidget(self.btnUp)
        leftBtns.addWidget(self.btnDown)
        leftBtns.addStretch(1)

        top = QtWidgets.QHBoxLayout()
        top.addWidget(self.lwLayers, 1)
        btnCol = QtWidgets.QWidget()
        btnCol.setLayout(leftBtns)
        top.addWidget(btnCol)

        form = QtWidgets.QFormLayout()
        form.addRow("Format:", self.cboFormat)
        outRow = QtWidgets.QHBoxLayout()
        outRow.addWidget(self.leOutput, 1)
        outRow.addWidget(self.btnBrowse)
        form.addRow("Output:", outRow)
        form.addRow("Options:", self.chkOverwrite)

        main = QtWidgets.QVBoxLayout(self)
        main.addLayout(top)
        main.addSpacing(8)
        main.addLayout(form)
        main.addWidget(self.progress)
        main.addWidget(self.txtLog, 1)
        main.addWidget(self.buttonBox)

        # Signals
        self.btnAddSelected.clicked.connect(self.addSelectedLayers)
        self.btnAddAll.clicked.connect(self.addAllVectorLayers)
        self.btnRemove.clicked.connect(self.removeSelected)
        self.btnUp.clicked.connect(lambda: self.moveSelected(-1))
        self.btnDown.clicked.connect(lambda: self.moveSelected(1))
        self.btnBrowse.clicked.connect(self.chooseOutput)
        self.cboFormat.currentIndexChanged.connect(self.syncOutputExtension)
        self.btnExport.clicked.connect(self.export)
        self.buttonBox.rejected.connect(self.reject)

    # ------------ Utility ------------
    def log(self, msg: str):
        self.txtLog.append(msg)
        try:
            self.iface.messageBar().pushMessage("Expor Data KML/GPKG", msg, level=QgsMessageBar.INFO, duration=3)
        except Exception:
            pass

    def warn(self, msg: str):
        self.txtLog.append("⚠️ " + msg)
        QtWidgets.QMessageBox.warning(self, "Expor Data KML/GPKG", msg)

    def info(self, msg: str):
        QtWidgets.QMessageBox.information(self, "Expor Data KML/GPKG", msg)

    def selectedLayerIdsInPanel(self):
        try:
            view = self.iface.layerTreeView()
            nodes = view.selectedLayerNodes() if hasattr(view, "selectedLayerNodes") else []
            ids = []
            for n in nodes or []:
                try:
                    lyr = n.layer()
                    if isinstance(lyr, QgsVectorLayer):
                        ids.append(lyr.id())
                except Exception:
                    continue
            if not ids:
                lyr = self.iface.activeLayer()
                if isinstance(lyr, QgsVectorLayer):
                    ids.append(lyr.id())
            return ids
        except Exception:
            return []

    def addLayerObjects(self, layers):
        existing_ids = set()
        for i in range(self.lwLayers.count()):
            existing_ids.add(self.lwLayers.item(i).data(QtCore.Qt.UserRole))
        added = 0
        for lyr in layers:
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.id() in existing_ids:
                continue
            item = QtWidgets.QListWidgetItem(f"{lyr.name()}  [CRS: {lyr.crs().authid()}]")
            item.setData(QtCore.Qt.UserRole, lyr.id())
            self.lwLayers.addItem(item)
            added += 1
        self.log(f"Added {added} vector layer(s).")

    def addSelectedLayers(self):
        ids = self.selectedLayerIdsInPanel()
        layers = [QgsProject.instance().mapLayer(i) for i in ids]
        self.addLayerObjects([l for l in layers if isinstance(l, QgsVectorLayer)])

    def addAllVectorLayers(self):
        layers = [l for l in QgsProject.instance().mapLayers().values() if isinstance(l, QgsVectorLayer)]
        self.addLayerObjects(layers)

    def removeSelected(self):
        for item in self.lwLayers.selectedItems():
            row = self.lwLayers.row(item)
            self.lwLayers.takeItem(row)
        self.log("Removed selected.")

    def moveSelected(self, delta):
        row = self.lwLayers.currentRow()
        if row < 0:
            return
        new_row = max(0, min(self.lwLayers.count() - 1, row + delta))
        if new_row == row:
            return
        item = self.lwLayers.takeItem(row)
        self.lwLayers.insertItem(new_row, item)
        self.lwLayers.setCurrentRow(new_row)

    def currentFormat(self):
        return self.cboFormat.currentText().strip()

    def syncOutputExtension(self):
        fmt = self.currentFormat()
        path = self.leOutput.text().strip()
        if not path:
            return
        base, ext = os.path.splitext(path)
        desired_ext = ".gpkg" if fmt == "GPKG" else ".kml"
        if ext.lower() != desired_ext:
            self.leOutput.setText(base + desired_ext)

    def chooseOutput(self):
        fmt = self.currentFormat()
        filt = "GeoPackage (*.gpkg)" if fmt == "GPKG" else "KML (*.kml)"
        suffix = "gpkg" if fmt == "GPKG" else "kml"
        fn, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Choose output file", "", filt)
        if not fn:
            return
        if not fn.lower().endswith("." + suffix):
            fn += "." + suffix
        self.leOutput.setText(fn)

    def export(self):
        # Collect layers
        layers = []
        for i in range(self.lwLayers.count()):
            lyr_id = self.lwLayers.item(i).data(QtCore.Qt.UserRole)
            lyr = QgsProject.instance().mapLayer(lyr_id)
            if isinstance(lyr, QgsVectorLayer):
                layers.append(lyr)
        if not layers:
            self.warn("Please add at least one vector layer.")
            return

        out_path = self.leOutput.text().strip()
        if not out_path:
            self.warn("Please choose an output file path.")
            return

        fmt = self.currentFormat()
        overwrite = self.chkOverwrite.isChecked()

        out_dir = os.path.dirname(out_path)
        if out_dir and not os.path.exists(out_dir):
            try:
                os.makedirs(out_dir, exist_ok=True)
            except Exception as e:
                self.warn("Cannot create output folder: {}\\n{}".format(out_dir, e))
                return

        no_crs = [l.name() for l in layers if not l.crs().isValid()]
        if no_crs:
            self.warn("Some layers have no CRS defined:\\n- " + "\\n- ".join(no_crs) + "\\nPlease set their CRS before exporting.")
            return

        if os.path.exists(out_path):
            if not overwrite:
                self.warn("Output file exists: " + out_path + "\\nEnable 'Overwrite' to replace it.")
                return
            try:
                os.remove(out_path)
            except Exception:
                pass

        self.progress.setValue(0)
        self.txtLog.clear()

        # Choose driver
        if fmt == "GPKG":
            driver = "GPKG"
        else:
            driver = "LIBKML" if has_ogr_driver("LIBKML") else "KML"

        self.log("Start export → {} (driver: {}) : {}".format(fmt, driver, out_path))

        dest_crs = QgsCoordinateReferenceSystem("EPSG:4326")
        tctx = QgsProject.instance().transformContext()

        ok_count = 0
        fail = []

        total = len(layers)
        for idx, layer in enumerate(layers, 1):
            self.progress.setValue(int((idx / float(total)) * 100))
            QtWidgets.QApplication.processEvents()

            src_name = layer.name()
            allow_unicode = (driver in ("GPKG", "LIBKML"))
            safe_name = sanitize_layer_name(src_name, allow_unicode=allow_unicode)
            geom_class = QgsWkbTypes.displayString(layer.wkbType())
            self.log("Exporting: {}  (geom: {}) → layer '{}'".format(src_name, geom_class, safe_name))

            first = (idx == 1)
            err_code, err_msg = do_export_layer(layer, out_path, driver, safe_name, dest_crs, tctx, first)

            # If failed and we used Unicode, retry once with ASCII-safe name
            if err_code != 0 and allow_unicode:
                ascii_name = sanitize_layer_name(src_name, allow_unicode=False)
                if ascii_name != safe_name:
                    self.log("Retrying with ASCII layer name: '{}'".format(ascii_name))
                    err_code, err_msg = do_export_layer(layer, out_path, driver, ascii_name, dest_crs, tctx, first)

            if err_code == 0:
                ok_count += 1
                self.log("✔ Done: " + src_name)
            else:
                if driver == "KML" and total > 1 and not err_msg:
                    err_msg = "KML driver on this GDAL build supports only one layer per file; use GPKG or install LIBKML."
                fail.append((src_name, err_msg))
                self.log("✖ Failed: {} → {}".format(src_name, err_msg or "(unknown OGR error)"))

        self.progress.setValue(100)

        if fail:
            lines = ["Export finished with errors. Success: {}/{}".format(ok_count, len(layers)), "", "Failures:"]
            for n, e in fail:
                lines.append("- {}: {}".format(n, e))
            self.warn("\\n".join(lines))
        else:
            self.info("Export complete. {} layer(s) written to\\n{}".format(ok_count, out_path))
            self.log("All done.")


def has_ogr_driver(name: str) -> bool:
    try:
        return ogr is not None and ogr.GetDriverByName(name) is not None
    except Exception:
        return False


def sanitize_layer_name(name: str, allow_unicode: bool = True) -> str:
    """
    If allow_unicode=True  → keep Thai/Unicode; just normalize whitespace and forbid path-like chars.
    If allow_unicode=False → ASCII-only, replace others with underscore.
    """
    name = (name or "").strip()
    if not name:
        name = "layer"
    # normalize whitespace
    name = re.sub(r"\s+", "_", name)
    # forbid path/meta characters which may confuse drivers
    name = re.sub(r'[\\/:*?"<>|]', "_", name)
    if allow_unicode:
        # Keep unicode as-is
        pass
    else:
        # Strip to ASCII underscores/digits/letters
        try:
            # fast ascii fallback
            name_ascii = name.encode("ascii", "ignore").decode("ascii")
        except Exception:
            name_ascii = name
        name = re.sub(r"[^0-9A-Za-z_]+", "_", name_ascii)
    # collapse multiple underscores
    name = re.sub(r"_+", "_", name).strip("_")
    if not name:
        name = "layer"
    # conservative length cap
    return name[:63]


def do_export_layer(layer, out_path, driver, layer_name, dest_crs, tctx, first_layer: bool):
    # Preferred path
    try:
        if QgsVectorLayerExporter and hasattr(QgsVectorLayerExporter, "SaveVectorOptions"):
            options = QgsVectorLayerExporter.SaveVectorOptions()
            options.driverName = driver
            options.fileEncoding = "UTF-8"
            options.onlySelected = False
            options.layerName = layer_name
            options.destCRS = dest_crs
            options.ct = QgsCoordinateTransform(layer.crs(), dest_crs, tctx)
            options.actionOnExistingFile = (
                getattr(QgsVectorLayerExporter, "CreateOrOverwriteFile", 0)
                if first_layer else
                getattr(QgsVectorLayerExporter, "CreateOrOverwriteLayer", 0)
            )
            res = QgsVectorLayerExporter.exportLayer(layer, out_path, driver, options, tctx)
            try:
                return res.errorCode(), res.errorMessage()
            except Exception:
                if isinstance(res, (tuple, list)) and len(res) >= 2:
                    return res[0], res[1]
                return 0, ""
    except Exception:
        pass

    # Fallback
    try:
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = driver
        options.fileEncoding = "UTF-8"
        options.onlySelected = False
        options.layerName = layer_name
        options.destCRS = dest_crs
        options.ct = QgsCoordinateTransform(layer.crs(), dest_crs, tctx)
        options.actionOnExistingFile = (
            getattr(QgsVectorFileWriter, "CreateOrOverwriteFile", 0)
            if first_layer else
            getattr(QgsVectorFileWriter, "CreateOrOverwriteLayer", 0)
        )
        return QgsVectorFileWriter.writeAsVectorFormatV2(layer, out_path, tctx, options)
    except Exception as e:
        return 1, str(e)
