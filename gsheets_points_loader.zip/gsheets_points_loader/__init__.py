def classFactory(iface):
    from .gsheets_points_loader import GSheetsPointsLoader
    return GSheetsPointsLoader(iface)