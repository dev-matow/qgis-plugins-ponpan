from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtWidgets import QAction, QInputDialog, QMessageBox
from qgis.PyQt.QtGui import QIcon

from qgis.core import (
    QgsVectorLayer,
    QgsProject,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY
)

from PyQt5.QtCore import QVariant

import csv
import io
import urllib.request


class GSheetsPointsLoader:
    """
    QGIS Plugin: Load Google Sheets CSV to a Point layer (EPSG:4326)
    - Setup action: set URL + layer name
    - Refresh action: fetch CSV again and update layer
    - Supports:
        1) latitude + longitude columns (also lat/lon/lng)
        2) Location column containing "lat,lon"
    """

    def __init__(self, iface):
        self.iface = iface
        self.menu_name = "&GSheets Points Loader"

        self.action_setup = None
        self.action_refresh = None

        self.layer = None

        # persistent settings
        self.settings = QSettings()
        self.key_url = "gsheets_points_loader/csv_url"
        self.key_layer_name = "gsheets_points_loader/layer_name"

        self.csv_url = self.settings.value(self.key_url, "", type=str)
        self.layer_name = self.settings.value(self.key_layer_name, "GSheets_Points", type=str)

    def initGui(self):
        # Setup button
        self.action_setup = QAction("GSheets Setup", self.iface.mainWindow())
        self.action_setup.setToolTip("ตั้งค่า Google Sheets CSV URL และชื่อเลเยอร์")
        self.action_setup.triggered.connect(self.setup)

        # Refresh button
        self.action_refresh = QAction("GSheets Refresh", self.iface.mainWindow())
        self.action_refresh.setToolTip("ดึงข้อมูลจาก Google Sheets ใหม่ แล้วอัปเดตเลเยอร์")
        self.action_refresh.triggered.connect(self.refresh)

        # Add to menu + toolbar
        self.iface.addPluginToMenu(self.menu_name, self.action_setup)
        self.iface.addPluginToMenu(self.menu_name, self.action_refresh)
        self.iface.addToolBarIcon(self.action_setup)
        self.iface.addToolBarIcon(self.action_refresh)

        # Optional: if URL already exists, you can refresh once at startup
        # (comment out if you don't want)
        # if self.csv_url:
        #     self.refresh()

    def unload(self):
        if self.action_setup:
            self.iface.removePluginMenu(self.menu_name, self.action_setup)
            self.iface.removeToolBarIcon(self.action_setup)
        if self.action_refresh:
            self.iface.removePluginMenu(self.menu_name, self.action_refresh)
            self.iface.removeToolBarIcon(self.action_refresh)

    # -------------------------
    # UI actions
    # -------------------------
    def setup(self):
        url, ok = QInputDialog.getText(
            self.iface.mainWindow(),
            "GSheets Setup",
            "ใส่ URL CSV (เช่น .../pub?output=csv หรือ .../export?format=csv&gid=0):",
            text=self.csv_url
        )
        if not ok:
            return
        url = (url or "").strip()
        if not url:
            QMessageBox.warning(self.iface.mainWindow(), "GSheets Setup", "URL ว่าง กรุณาใส่ URL CSV")
            return

        lname, ok = QInputDialog.getText(
            self.iface.mainWindow(),
            "GSheets Setup",
            "ชื่อเลเยอร์ใน QGIS:",
            text=self.layer_name
        )
        if not ok:
            return
        lname = (lname or "").strip()
        if not lname:
            lname = "GSheets_Points"

        self.csv_url = url
        self.layer_name = lname

        self.settings.setValue(self.key_url, self.csv_url)
        self.settings.setValue(self.key_layer_name, self.layer_name)

        self.iface.messageBar().pushMessage("GSheets", "บันทึกการตั้งค่าแล้ว (กด Refresh เพื่อดึงข้อมูล)", level=0, duration=4)

    def refresh(self):
        if not self.csv_url:
            QMessageBox.warning(self.iface.mainWindow(), "GSheets Refresh", "ยังไม่ได้ตั้งค่า URL (กด GSheets Setup ก่อน)")
            return

        try:
            text = self._download_text(self.csv_url)
            rows, headers = self._parse_csv(text)

            if not headers:
                QMessageBox.warning(self.iface.mainWindow(), "GSheets", "อ่านหัวตารางไม่สำเร็จ (CSV ไม่มี header)")
                return

            if not rows:
                QMessageBox.warning(self.iface.mainWindow(), "GSheets", "ไม่พบข้อมูลแถวใน CSV")
                return

            lat_key, lon_key, loc_key = self._detect_coord_fields(headers)

            if not ((lat_key and lon_key) or loc_key):
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    "GSheets",
                    "ไม่พบคอลัมน์พิกัด\nต้องมี latitude+longitude (หรือ lat/lon/lng) หรือ Location (lat,lon)"
                )
                return

            self._build_or_update_layer(headers, rows, lat_key, lon_key, loc_key)

        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "GSheets Error", f"เกิดข้อผิดพลาด:\n{e}")

    # -------------------------
    # Core helpers
    # -------------------------
    def _download_text(self, url: str) -> str:
        # Use a browser-like User-Agent to avoid being blocked
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = resp.read()
        # utf-8-sig handles BOM if present
        return data.decode("utf-8-sig", errors="replace")

    def _parse_csv(self, text: str):
        f = io.StringIO(text)
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        rows = list(reader)
        return rows, headers

    def _detect_coord_fields(self, headers):
        # map lowercase header -> original header
        lower_map = {h.strip().lower(): h for h in headers if h}

        lat_key = lower_map.get("latitude") or lower_map.get("lat")
        lon_key = lower_map.get("longitude") or lower_map.get("lon") or lower_map.get("lng")

        # Location column that stores "lat,lon"
        loc_key = lower_map.get("location") or lower_map.get("loc") or lower_map.get("point")
        return lat_key, lon_key, loc_key

    def _build_or_update_layer(self, headers, rows, lat_key, lon_key, loc_key):
        # Create memory layer if missing or removed
        if self.layer is None or QgsProject.instance().mapLayer(self.layer.id()) is None:
            self.layer = QgsVectorLayer("Point?crs=EPSG:4326", self.layer_name, "memory")
            pr = self.layer.dataProvider()

            fields = QgsFields()
            for h in headers:
                fields.append(QgsField(h, QVariant.String))
            pr.addAttributes(fields)
            self.layer.updateFields()

            QgsProject.instance().addMapLayer(self.layer)

        # Update layer name in case user changed it
        if self.layer.name() != self.layer_name:
            self.layer.setName(self.layer_name)

        # Truncate old features and insert new ones
        self.layer.startEditing()
        self.layer.dataProvider().truncate()

        feats = []
        for r in rows:
            lat, lon = None, None

            if lat_key and lon_key:
                lat = self._to_float(r.get(lat_key, ""))
                lon = self._to_float(r.get(lon_key, ""))
            elif loc_key:
                lat, lon = self._parse_location(r.get(loc_key, ""))

            if lat is None or lon is None:
                continue

            feat = QgsFeature(self.layer.fields())
            feat.setAttributes([r.get(h, "") for h in headers])
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
            feats.append(feat)

        self.layer.addFeatures(feats)
        self.layer.commitChanges()
        self.layer.triggerRepaint()

        self.iface.messageBar().pushMessage(
            "GSheets",
            f"อัปเดตสำเร็จ: {len(feats)} จุด",
            level=0,
            duration=4
        )

    def _to_float(self, x):
        try:
            s = str(x).strip()
            if s == "":
                return None
            return float(s)
        except Exception:
            return None

    def _parse_location(self, s):
        try:
            s = str(s).strip()
            if not s:
                return (None, None)
            parts = [p.strip() for p in s.split(",")]
            if len(parts) != 2:
                return (None, None)
            lat = float(parts[0])
            lon = float(parts[1])
            return (lat, lon)
        except Exception:
            return (None, None)