from qgis.PyQt.QtCore import QSettings, QTimer
from qgis.PyQt.QtWidgets import QAction, QInputDialog, QMessageBox
from qgis.core import (
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
)
from PyQt5.QtCore import QVariant

import csv
import io
import urllib.request


class GSheetsPointsLoader:
    AUTO_REFRESH_SECONDS = 10800  # 3 hours

    def __init__(self, iface):
        self.iface = iface
        self.menu_name = "&GSheets Points Loader"

        self.action_setup = None
        self.action_refresh = None

        self.layer = None

        self.settings = QSettings()
        self.key_default_layer_name = "gsheets_points_loader/default_layer_name"

        self.project_scope = "gsheets_points_loader"
        self.project_key_enabled = "enabled"
        self.project_key_url = "csv_url"
        self.project_key_layer_name = "layer_name"

        self.enabled_for_project = False
        self.csv_url = ""
        self.layer_name = self.settings.value(self.key_default_layer_name, "GSheets_Points", type=str)

        self.timer = QTimer()
        self.timer.timeout.connect(self.refresh)

    def initGui(self):
        self.action_setup = QAction("GSheets Setup", self.iface.mainWindow())
        self.action_setup.triggered.connect(self.setup)

        self.action_refresh = QAction("GSheets Refresh", self.iface.mainWindow())
        self.action_refresh.triggered.connect(self.refresh)

        self.iface.addPluginToMenu(self.menu_name, self.action_setup)
        self.iface.addPluginToMenu(self.menu_name, self.action_refresh)

        self.iface.addToolBarIcon(self.action_setup)
        self.iface.addToolBarIcon(self.action_refresh)

        self.iface.projectRead.connect(self._on_project_read)
        if hasattr(self.iface, "newProjectCreated"):
            self.iface.newProjectCreated.connect(self._on_project_read)

        self._on_project_read()

    def unload(self):
        if self.action_setup:
            self.iface.removePluginMenu(self.menu_name, self.action_setup)
            self.iface.removeToolBarIcon(self.action_setup)
        if self.action_refresh:
            self.iface.removePluginMenu(self.menu_name, self.action_refresh)
            self.iface.removeToolBarIcon(self.action_refresh)

        try:
            self.iface.projectRead.disconnect(self._on_project_read)
        except Exception:
            pass
        if hasattr(self.iface, "newProjectCreated"):
            try:
                self.iface.newProjectCreated.disconnect(self._on_project_read)
            except Exception:
                pass

        self.timer.stop()

    # -------------------------
    # Setup
    # -------------------------
    def setup(self):
        self._load_project_settings()

        url, ok = QInputDialog.getText(
            self.iface.mainWindow(),
            "GSheets Setup",
            "CSV URL:",
            text=self.csv_url,
        )
        if not ok:
            return

        url = (url or "").strip()
        if not url:
            QMessageBox.warning(self.iface.mainWindow(), "GSheets Setup", "URL is empty")
            return

        lname, ok = QInputDialog.getText(
            self.iface.mainWindow(),
            "GSheets Setup",
            "Layer name:",
            text=self.layer_name,
        )
        if not ok:
            return

        self.csv_url = url
        self.layer_name = lname.strip() if lname else "GSheets_Points"
        self.enabled_for_project = True

        self.settings.setValue(self.key_default_layer_name, self.layer_name)
        self._save_project_settings()

        # Start auto-refresh immediately for this project
        self.refresh()
        self.timer.start(self.AUTO_REFRESH_SECONDS * 1000)

        self.iface.messageBar().pushMessage(
            "GSheets",
            "Settings saved for this project. Auto refresh every 3 hours started.",
            level=0,
            duration=5,
        )

    # -------------------------
    # Refresh Logic
    # -------------------------
    def _load_project_settings(self):
        project = QgsProject.instance()

        self.enabled_for_project = project.readBoolEntry(
            self.project_scope, self.project_key_enabled, False
        )[0]
        self.csv_url = project.readEntry(
            self.project_scope, self.project_key_url, ""
        )[0]
        self.layer_name = project.readEntry(
            self.project_scope,
            self.project_key_layer_name,
            self.settings.value(self.key_default_layer_name, "GSheets_Points", type=str),
        )[0]

    def _save_project_settings(self):
        project = QgsProject.instance()
        project.writeEntry(self.project_scope, self.project_key_enabled, self.enabled_for_project)
        project.writeEntry(self.project_scope, self.project_key_url, self.csv_url)
        project.writeEntry(self.project_scope, self.project_key_layer_name, self.layer_name)

    def _on_project_read(self):
        self.timer.stop()
        self._load_project_settings()
        self.layer = None
        if not self.enabled_for_project or not self.csv_url:
            return

        self.refresh()
        self.timer.start(self.AUTO_REFRESH_SECONDS * 1000)
        self.iface.messageBar().pushMessage(
            "GSheets",
            "Project is enabled. Auto refresh every 3 hours started.",
            level=0,
            duration=5,
        )

    def refresh(self):
        if not self.enabled_for_project or not self.csv_url:
            return

        try:
            text = self._download_text(self.csv_url)
            rows, headers = self._parse_csv(text)

            lat_key, lon_key, loc_key = self._detect_coord_fields(headers)

            if not ((lat_key and lon_key) or loc_key):
                return

            self._build_or_update_layer(headers, rows, lat_key, lon_key, loc_key)

        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "GSheets Error", str(e))

    def _download_text(self, url: str) -> str:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = resp.read()
        return data.decode("utf-8-sig", errors="replace")

    def _parse_csv(self, text: str):
        f = io.StringIO(text)
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        rows = list(reader)
        return rows, headers

    def _detect_coord_fields(self, headers):
        lower_map = {h.lower(): h for h in headers}

        lat_key = lower_map.get("latitude") or lower_map.get("lat")
        lon_key = lower_map.get("longitude") or lower_map.get("lon") or lower_map.get("lng")
        loc_key = lower_map.get("location")

        return lat_key, lon_key, loc_key

    def _build_or_update_layer(self, headers, rows, lat_key, lon_key, loc_key):
        self.layer = self._get_or_create_layer(headers)
        if self.layer is None:
            return

        self.layer.startEditing()
        self.layer.dataProvider().truncate()

        feats = []

        for r in rows:
            lat, lon = None, None

            if lat_key and lon_key:
                lat = self._to_float(r.get(lat_key))
                lon = self._to_float(r.get(lon_key))
            elif loc_key:
                lat, lon = self._parse_location(r.get(loc_key))

            if lat is None or lon is None:
                continue

            feat = QgsFeature(self.layer.fields())
            feat.setAttributes([r.get(h, "") for h in headers])
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
            feats.append(feat)

        self.layer.addFeatures(feats)
        self.layer.commitChanges()
        self.layer.triggerRepaint()

    def _get_or_create_layer(self, headers):
        project = QgsProject.instance()

        if self.layer is not None and project.mapLayer(self.layer.id()) is not None:
            if self._layer_fields(self.layer) == headers:
                return self.layer
            project.removeMapLayer(self.layer.id())
            self.layer = None

        candidate_layers = []
        for lyr in project.mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.name() != self.layer_name:
                continue
            if lyr.geometryType() != QgsWkbTypes.PointGeometry:
                continue
            candidate_layers.append(lyr)

        selected = None
        for lyr in candidate_layers:
            if self._layer_fields(lyr) == headers:
                selected = lyr
                break

        # Keep only one matching layer (if found); remove duplicates.
        for lyr in candidate_layers:
            if selected is None or lyr.id() != selected.id():
                project.removeMapLayer(lyr.id())

        if selected is not None:
            return selected

        layer = QgsVectorLayer("Point?crs=EPSG:4326", self.layer_name, "memory")
        pr = layer.dataProvider()

        fields = QgsFields()
        for h in headers:
            fields.append(QgsField(h, QVariant.String))
        pr.addAttributes(fields)
        layer.updateFields()

        project.addMapLayer(layer)
        return layer

    def _layer_fields(self, layer):
        return [f.name() for f in layer.fields()]

    def _to_float(self, x):
        try:
            return float(str(x).strip())
        except Exception:
            return None

    def _parse_location(self, s):
        try:
            parts = str(s).split(",")
            return float(parts[0]), float(parts[1])
        except Exception:
            return None, None
